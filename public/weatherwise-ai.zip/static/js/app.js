/**
 * WeatherWise AI - Main Client Application Logic
 * Integrates live weather, safety score gauge, animated weather canvas,
 * AI Gemini chatbot, Web Speech voice input, and profile-based alerts.
 */

// Global State
let currentCity = "New Delhi";
let currentProfile = "General Citizen";
let currentLanguage = "en"; // 'en' or 'hi'
let latestWeatherData = null;
let latestForecastData = null;
let speechRecognition = null;
let isRecording = false;

// Multilingual Dictionary
const I18N = {
  en: {
    nav_dashboard: "Dashboard",
    nav_chat: "AI Weather Chat",
    nav_forecast: "7-Day Forecast",
    nav_alerts: "Weather Alerts",
    nav_climate: "Climate Insights",
    active_profile: "Active Mode",
    search: "Search",
    current_location: "My Location",
    humidity: "Humidity",
    wind: "Wind Speed",
    pressure: "Pressure",
    uv_index: "UV Index",
    sun_cycle: "Sun Cycle",
    safety_score_title: "Weather Safety Score",
    chart_trends_title: "Hourly Meteorological Trends (24h)",
    seven_day_title: "7-Day Intelligent Forecast",
    try_asking: "Try asking:",
    speech_hint: "Web Speech API ready. Click microphone to speak."
  },
  hi: {
    nav_dashboard: "डैशबोर्ड",
    nav_chat: "एआई मौसम चैट",
    nav_forecast: "7-दिवसीय पूर्वानुमान",
    nav_alerts: "मौसम चेतावनी",
    nav_climate: "जलवायु रुझान",
    active_profile: "सक्रिय मोड",
    search: "खोजें",
    current_location: "मेरा स्थान",
    humidity: "आर्द्रता",
    wind: "हवा की गति",
    pressure: "वायुमंडलीय दबाव",
    uv_index: "यूवी सूचकांक",
    sun_cycle: "सूर्योदय / सूर्यास्त",
    safety_score_title: "मौसम सुरक्षा स्कोर",
    chart_trends_title: "24-घंटे मौसमी रुझान",
    seven_day_title: "7-दिवसीय स्मार्ट पूर्वानुमान",
    try_asking: "पूछ कर देखें:",
    speech_hint: "माइक तैयार है। बोलने के लिए क्लिक करें।"
  }
};

document.addEventListener("DOMContentLoaded", () => {
  initLucideIcons();
  initNavigation();
  initSearchAndGeolocation();
  initProfileSelector();
  initLanguageToggle();
  initChatEngine();
  initVoiceInput();
  initChartTabs();
  initWeatherCanvas();

  // Initial Data Load
  loadWeatherData(currentCity);
  loadClimateData();
});

function initLucideIcons() {
  if (window.lucide) {
    window.lucide.createIcons();
  }
}

/**
 * Tab Navigation (Dashboard, Chat, Forecast, Alerts, Climate)
 */
function initNavigation() {
  const navBtns = document.querySelectorAll(".nav-item");
  navBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      const targetView = btn.getAttribute("data-view");
      switchView(targetView);
    });
  });

  const consultBtn = document.getElementById("cta-ask-gemini");
  if (consultBtn) {
    consultBtn.addEventListener("click", () => {
      switchView("chat");
    });
  }
}

function switchView(viewName) {
  document.querySelectorAll(".nav-item").forEach(b => b.classList.remove("active"));
  const activeNav = document.getElementById(`nav-${viewName}`);
  if (activeNav) activeNav.classList.add("active");

  document.querySelectorAll(".app-view").forEach(v => v.classList.remove("active"));
  const activeView = document.getElementById(`view-${viewName}`);
  if (activeView) activeView.classList.add("active");

  // Re-trigger chart render if needed
  if (viewName === 'dashboard' && latestForecastData) {
    setTimeout(() => {
      renderWeatherTrendsChart(latestForecastData.hourly, currentActiveChartType);
    }, 50);
  }
}

/**
 * Search Bar & Geolocation
 */
function initSearchAndGeolocation() {
  const searchInput = document.getElementById("city-search-input");
  const searchBtn = document.getElementById("search-btn");
  const geoBtn = document.getElementById("geo-btn");

  const executeSearch = () => {
    const q = searchInput.value.trim();
    if (q) {
      currentCity = q;
      loadWeatherData(q);
    }
  };

  searchBtn.addEventListener("click", executeSearch);
  searchInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") executeSearch();
  });

  geoBtn.addEventListener("click", () => {
    if (!navigator.geolocation) {
      showToast("Geolocation is not supported by your browser.", "error");
      return;
    }
    showToast("Detecting current coordinates...", "info");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;
        loadWeatherDataByCoords(lat, lon);
      },
      (err) => {
        showToast("Location access denied or timed out. Defaulting to New Delhi.", "warning");
        loadWeatherData("New Delhi");
      },
      { timeout: 8000 }
    );
  });
}

/**
 * Profile Mode Selector
 */
function initProfileSelector() {
  const selector = document.getElementById("profile-selector");
  const profileDesc = document.getElementById("profile-desc");
  const aiBannerProfile = document.getElementById("ai-banner-profile");
  const chatCtxProfile = document.getElementById("chat-ctx-profile");

  const descs = {
    "General Citizen": "Optimized advice for daily citizen routine and safe travel.",
    "Farmer": "Agricultural risk assessment: rainfall timings, soil moisture, and spray windows.",
    "Traveler": "Transit safety, highway visibility, storm delays, and trip feasibility.",
    "Emergency Services": "Critical civil alert triggers, drainage overflow, and hazard staging."
  };

  selector.addEventListener("change", (e) => {
    currentProfile = e.target.value;
    profileDesc.textContent = descs[currentProfile] || descs["General Citizen"];
    if (aiBannerProfile) aiBannerProfile.textContent = currentProfile;
    if (chatCtxProfile) chatCtxProfile.textContent = currentProfile;
    showToast(`Switched profile to ${currentProfile}`, "info");

    // Re-evaluate alerts for the new profile
    if (latestWeatherData) {
      updateAlertsForProfile(currentProfile);
    }
  });
}

/**
 * Multilingual Language Toggle (EN / HI)
 */
function initLanguageToggle() {
  const langBtn = document.getElementById("lang-toggle-btn");
  const langText = document.getElementById("current-lang-text");

  langBtn.addEventListener("click", () => {
    currentLanguage = currentLanguage === "en" ? "hi" : "en";
    langText.textContent = currentLanguage === "en" ? "EN | हिंदी" : "हिंदी | EN";
    applyLanguageTranslations();
    showToast(currentLanguage === "en" ? "Language set to English" : "भाषा हिंदी में सेट की गई", "info");
  });
}

function applyLanguageTranslations() {
  const dict = I18N[currentLanguage];
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.getAttribute("data-i18n");
    if (dict[key]) {
      el.textContent = dict[key];
    }
  });

  // Re-render safety advisory in selected language
  if (latestWeatherData && latestWeatherData.safety) {
    const advEl = document.getElementById("safety-advisory-text");
    const lvlEl = document.getElementById("safety-level-badge");
    if (currentLanguage === "hi") {
      advEl.textContent = latestWeatherData.safety.advisory_hindi || latestWeatherData.safety.advisory;
      lvlEl.textContent = latestWeatherData.safety.level_hindi || latestWeatherData.safety.level;
    } else {
      advEl.textContent = latestWeatherData.safety.advisory;
      lvlEl.textContent = latestWeatherData.safety.level;
    }
  }
}

/**
 * Fetch Weather & Forecast Data from Flask Backend
 */
async function loadWeatherData(city) {
  try {
    setTopbarStatus("Fetching Data...", true);
    const resp = await fetch(`/api/weather?city=${encodeURIComponent(city)}&profile=${encodeURIComponent(currentProfile)}`);
    const data = await resp.json();

    if (!data || !data.success) {
      showToast(data?.error || "Failed to load weather data.", "error");
      return;
    }

    latestWeatherData = data;
    renderDashboardCurrent(data.current);
    renderSafetyScore(data.safety);
    renderAlerts(data.alerts);

    // Also fetch forecast & hourly
    const fResp = await fetch(`/api/forecast?city=${encodeURIComponent(city)}`);
    const fData = await fResp.json();
    if (fData.success) {
      latestForecastData = fData;
      renderForecast(fData.forecast);
      renderWeatherTrendsChart(fData.hourly, currentActiveChartType);
    }

    // Update Chat Context Badges
    const chatLoc = document.getElementById("chat-ctx-location");
    if (chatLoc) chatLoc.textContent = data.current.location.split(",")[0];

    // Update Weather Particle Canvas Theme
    updateWeatherCanvasMood(data.current.condition, data.current.icon);

    setTopbarStatus("Live Synchronized", false);
    initLucideIcons();
  } catch (err) {
    console.error("Load weather failed:", err);
    showToast("Network error connecting to backend.", "error");
    setTopbarStatus("Offline / Demo", false);
  }
}

async function loadWeatherDataByCoords(lat, lon) {
  try {
    setTopbarStatus("Locating Coordinates...", true);
    const resp = await fetch(`/api/weather?lat=${lat}&lon=${lon}&profile=${encodeURIComponent(currentProfile)}`);
    const data = await resp.json();
    if (data.success) {
      latestWeatherData = data;
      renderDashboardCurrent(data.current);
      renderSafetyScore(data.safety);
      renderAlerts(data.alerts);

      const fResp = await fetch(`/api/forecast?lat=${lat}&lon=${lon}`);
      const fData = await fResp.json();
      if (fData.success) {
        latestForecastData = fData;
        renderForecast(fData.forecast);
        renderWeatherTrendsChart(fData.hourly, currentActiveChartType);
      }
      initLucideIcons();
      showToast(`Position locked: ${data.current.location}`, "info");
    }
  } catch (e) {
    console.error(e);
  }
}

/**
 * Render Current Weather Hero Card
 */
function renderDashboardCurrent(curr) {
  document.getElementById("hero-location").textContent = curr.location;
  document.getElementById("hero-last-updated").textContent = `Updated ${curr.last_updated}`;
  document.getElementById("hero-temp").textContent = Math.round(curr.temperature);
  document.getElementById("hero-condition").textContent = curr.condition;
  document.getElementById("hero-feels-like").textContent = `Feels like ${curr.feels_like}°C`;
  document.getElementById("hero-humidity").textContent = `${curr.humidity}%`;
  document.getElementById("hero-wind").textContent = `${curr.wind_speed} km/h`;
  document.getElementById("hero-pressure").textContent = `${curr.pressure} hPa`;
  document.getElementById("hero-uv").textContent = `${curr.uv_index} UV`;
  document.getElementById("hero-sun-cycle").textContent = `${curr.sunrise} / ${curr.sunset}`;

  // Demo badge
  const demoBadge = document.getElementById("demo-indicator");
  if (demoBadge) {
    demoBadge.style.display = curr.is_demo ? "inline-block" : "none";
  }

  // Weather Icon
  const iconContainer = document.getElementById("weather-icon-container");
  if (iconContainer) {
    iconContainer.innerHTML = `<i data-lucide="${curr.icon}" class="animated-hero-icon"></i>`;
  }
}

/**
 * Render Safety Score Circular Meter (SVG Stroke Offset)
 */
function renderSafetyScore(safety) {
  if (!safety) return;
  const numEl = document.getElementById("safety-score-number");
  const gaugeCircle = document.getElementById("gauge-circle");
  const levelBadge = document.getElementById("safety-level-badge");
  const advisoryEl = document.getElementById("safety-advisory-text");
  const factorsList = document.getElementById("safety-factors-list");

  numEl.textContent = safety.score;
  levelBadge.textContent = currentLanguage === 'hi' ? safety.level_hindi : safety.level;
  levelBadge.style.color = safety.color;
  levelBadge.style.borderColor = safety.color;

  advisoryEl.textContent = currentLanguage === 'hi' ? safety.advisory_hindi : safety.advisory;

  // Circumference of r=50 is 2 * PI * 50 = 314.15
  const circumference = 314;
  const offset = circumference - (safety.score / 100) * circumference;
  gaugeCircle.style.strokeDashoffset = offset;
  gaugeCircle.style.stroke = safety.color;

  // Deductions chips
  factorsList.innerHTML = "";
  if (safety.deductions) {
    safety.deductions.forEach(d => {
      const chip = document.createElement("span");
      chip.className = "factor-chip";
      chip.textContent = d;
      factorsList.appendChild(chip);
    });
  }
}

/**
 * Render Alerts Section
 */
function renderAlerts(alerts) {
  const container = document.getElementById("active-alerts-container");
  const dot = document.getElementById("sidebar-alert-dot");
  const detailedList = document.getElementById("alerts-detailed-container");

  container.innerHTML = "";
  if (detailedList) detailedList.innerHTML = "";

  const hasCritical = alerts.some(a => a.severity === "CRITICAL" || a.severity === "WARNING");
  if (dot) dot.style.display = hasCritical ? "inline-block" : "none";

  alerts.forEach(alert => {
    const card = document.createElement("div");
    card.className = `alert-card-item ${alert.severity}`;

    card.innerHTML = `
      <div class="alert-icon-wrap">
        <i data-lucide="${alert.icon}"></i>
      </div>
      <div class="alert-main-content">
        <div class="alert-header-line">
          <span class="alert-title">${currentLanguage === 'hi' ? alert.title_hi : alert.title}</span>
          <span class="alert-sev-tag ${alert.severity}">${alert.severity}</span>
        </div>
        <p class="alert-desc">${currentLanguage === 'hi' ? alert.description_hi : alert.description}</p>
        <div class="alert-profile-advice">
          <strong>Mode Action (${currentProfile}):</strong> ${alert.profile_action}
        </div>
      </div>
    `;

    container.appendChild(card);
    if (detailedList) detailedList.appendChild(card.cloneNode(true));
  });
}

async function updateAlertsForProfile(profile) {
  try {
    const resp = await fetch("/api/alerts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        profile: profile,
        current: latestWeatherData?.current,
        forecast: latestForecastData?.forecast
      })
    });
    const res = await resp.json();
    if (res.success) {
      renderAlerts(res.alerts);
      initLucideIcons();
    }
  } catch (e) {
    console.error(e);
  }
}

/**
 * Render 7-Day Forecast Cards
 */
function renderForecast(forecastList) {
  const container = document.getElementById("forecast-cards-container");
  const detailedContainer = document.getElementById("forecast-detailed-container");
  container.innerHTML = "";
  if (detailedContainer) detailedContainer.innerHTML = "";

  forecastList.forEach((day, idx) => {
    const mini = document.createElement("div");
    mini.className = "forecast-card-mini";
    mini.innerHTML = `
      <span class="f-day">${day.day}</span>
      <span class="f-date">${day.date}</span>
      <div class="f-icon-wrap">
        <i data-lucide="${day.icon}"></i>
      </div>
      <div class="f-temps">
        <span class="f-max">${Math.round(day.max_temp)}°</span>
        <span class="f-min">${Math.round(day.min_temp)}°</span>
      </div>
      <span class="f-rain">
        <i data-lucide="droplet" style="width:11px;height:11px;"></i>
        ${day.rain_probability}%
      </span>
    `;
    container.appendChild(mini);

    // Detailed version
    if (detailedContainer) {
      const detailed = document.createElement("div");
      detailed.className = "forecast-detail-card card";
      detailed.innerHTML = `
        <div class="card-header-flex">
          <h4>${day.day} (${day.date})</h4>
          <span class="badge-mini">${day.condition}</span>
        </div>
        <div style="display:flex; align-items:center; gap:16px; margin: 12px 0;">
          <i data-lucide="${day.icon}" style="width:40px;height:40px;color:var(--accent-mint)"></i>
          <div>
            <div style="font-size:1.3rem;font-weight:700;">${day.max_temp}°C <span style="font-size:0.9rem;color:var(--text-muted)">/ ${day.min_temp}°C</span></div>
            <span style="font-size:0.8rem;color:var(--text-secondary)">Max Wind: ${day.wind_speed} km/h</span>
          </div>
        </div>
        <div style="font-size:0.82rem;color:#38BDF8;display:flex;align-items:center;gap:6px;">
          <i data-lucide="umbrella" style="width:14px;height:14px;"></i>
          Precipitation Likelihood: <strong>${day.rain_probability}%</strong>
        </div>
      `;
      detailedContainer.appendChild(detailed);
    }
  });

  initLucideIcons();
}

/**
 * Chart Tab Toggling
 */
function initChartTabs() {
  const tabs = document.querySelectorAll(".chart-tab");
  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      tabs.forEach(t => t.classList.remove("active"));
      tab.classList.add("active");
      const chartType = tab.getAttribute("data-chart");
      if (latestForecastData) {
        renderWeatherTrendsChart(latestForecastData.hourly, chartType);
      }
    });
  });
}

/**
 * AI Chatbot Engine
 */
function initChatEngine() {
  const input = document.getElementById("chat-input-field");
  const sendBtn = document.getElementById("chat-send-btn");
  const suggestions = document.querySelectorAll(".suggestion-chip");

  const submitQuery = async () => {
    const text = input.value.trim();
    if (!text) return;
    input.value = "";

    // Append user message
    appendChatMessage("user", text);

    // Show typing indicator
    const typingIndicator = document.getElementById("chat-typing-indicator");
    typingIndicator.style.display = "flex";

    try {
      const resp = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: text,
          profile: currentProfile,
          language: currentLanguage,
          weather_context: {
            current: latestWeatherData?.current,
            forecast: latestForecastData?.forecast,
            safety: latestWeatherData?.safety,
            alerts: latestWeatherData?.alerts
          }
        })
      });

      const res = await resp.json();
      typingIndicator.style.display = "none";

      if (res.success && res.response) {
        appendChatMessage("assistant", res.response);
      } else {
        appendChatMessage("assistant", "Apologies, I encountered an issue processing meteorological insights. Please try again.");
      }
    } catch (e) {
      typingIndicator.style.display = "none";
      appendChatMessage("assistant", "Unable to communicate with the AI server. Please verify your connection.");
    }
  };

  sendBtn.addEventListener("click", submitQuery);
  input.addEventListener("keypress", (e) => {
    if (e.key === "Enter") submitQuery();
  });

  suggestions.forEach(chip => {
    chip.addEventListener("click", () => {
      const q = chip.getAttribute("data-query");
      input.value = q;
      submitQuery();
    });
  });
}

function appendChatMessage(sender, text) {
  const container = document.getElementById("chat-messages-container");
  const msgDiv = document.createElement("div");
  msgDiv.className = `chat-message ${sender === 'user' ? 'user-msg' : 'assistant-msg'}`;

  const iconName = sender === 'user' ? 'user' : 'bot';
  const senderTitle = sender === 'user' ? 'You' : 'WeatherWise AI';

  // Format basic bold and bullet markdown
  let formatted = text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\n\n/g, '<br><br>')
    .replace(/\n•/g, '<br>•');

  const avatarHtml = sender === 'user' 
    ? '<i data-lucide="user"></i>' 
    : '<img src="/static/images/ai_assistant_pfp.jpg" alt="WeatherWise AI" style="width: 100%; height: 100%; object-fit: cover; border-radius: 8px;">';

  msgDiv.innerHTML = `
    <div class="msg-avatar" style="overflow: hidden; padding: 0;">
      ${avatarHtml}
    </div>
    <div class="msg-bubble">
      <div class="msg-sender">${senderTitle}</div>
      <div class="msg-text">${formatted}</div>
      <span class="msg-time">Just now</span>
    </div>
  `;

  container.appendChild(msgDiv);
  container.scrollTop = container.scrollHeight;
  initLucideIcons();
}

/**
 * Web Speech Voice Input
 */
function initVoiceInput() {
  const micBtn = document.getElementById("voice-mic-btn");
  const statusHint = document.getElementById("voice-status-hint");
  const input = document.getElementById("chat-input-field");

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    statusHint.textContent = "Voice input is not supported in this browser.";
    micBtn.style.opacity = "0.5";
    micBtn.disabled = true;
    return;
  }

  speechRecognition = new SpeechRecognition();
  speechRecognition.continuous = false;
  speechRecognition.interimResults = false;
  speechRecognition.lang = currentLanguage === 'hi' ? 'hi-IN' : 'en-US';

  speechRecognition.onstart = () => {
    isRecording = true;
    micBtn.classList.add("recording");
    statusHint.textContent = "Listening... Speak your weather question now.";
  };

  speechRecognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    input.value = transcript;
    statusHint.textContent = `Recognized: "${transcript}"`;
  };

  speechRecognition.onerror = (event) => {
    isRecording = false;
    micBtn.classList.remove("recording");
    statusHint.textContent = `Voice recognition error: ${event.error}`;
  };

  speechRecognition.onend = () => {
    isRecording = false;
    micBtn.classList.remove("recording");
    statusHint.textContent = "Click microphone to speak again.";
  };

  micBtn.addEventListener("click", () => {
    if (isRecording) {
      speechRecognition.stop();
    } else {
      speechRecognition.lang = currentLanguage === 'hi' ? 'hi-IN' : 'en-US';
      speechRecognition.start();
    }
  });
}

/**
 * Load Climate Insights
 */
async function loadClimateData() {
  try {
    const resp = await fetch("/api/climate");
    const data = await resp.json();
    if (data.success) {
      renderClimateTrendChart(data);
      const textEl = document.getElementById("climate-ai-text");
      if (textEl && data.climate_ai_summary) {
        textEl.textContent = data.climate_ai_summary;
      }
    }
  } catch (e) {
    console.warn("Climate data fetch omitted:", e);
  }
}

/**
 * Animated Ambient Weather Canvas (Rain drops, Sun glow, or Particle Drifts)
 */
let canvasAnimationId = null;
let particles = [];
let weatherCanvasMode = "clear"; // 'clear', 'rain', 'clouds'

function initWeatherCanvas() {
  const canvas = document.getElementById("weather-effect-canvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");

  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    createParticles(canvas.width, canvas.height);
  }

  window.addEventListener("resize", resize);
  resize();

  function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    for (let p of particles) {
      if (weatherCanvasMode === "rain") {
        ctx.strokeStyle = "rgba(56, 189, 248, 0.4)";
        ctx.lineWidth = p.size;
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x + p.vx * 2, p.y + p.vy * 5);
        ctx.stroke();

        p.x += p.vx;
        p.y += p.vy;
        if (p.y > canvas.height) { p.y = -10; p.x = Math.random() * canvas.width; }
      } else {
        // Floating subtle starlight / atmospheric dust particles
        ctx.fillStyle = "rgba(52, 211, 153, " + p.alpha + ")";
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();

        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0) p.x = canvas.width;
        if (p.x > canvas.width) p.x = 0;
        if (p.y < 0) p.y = canvas.height;
        if (p.y > canvas.height) p.y = 0;
      }
    }

    canvasAnimationId = requestAnimationFrame(animate);
  }

  animate();
}

function createParticles(width, height) {
  particles = [];
  const count = weatherCanvasMode === "rain" ? 85 : 45;
  for (let i = 0; i < count; i++) {
    particles.push({
      x: Math.random() * width,
      y: Math.random() * height,
      size: weatherCanvasMode === "rain" ? Math.random() * 1.5 + 1 : Math.random() * 2 + 1,
      vx: weatherCanvasMode === "rain" ? -0.8 : (Math.random() - 0.5) * 0.4,
      vy: weatherCanvasMode === "rain" ? Math.random() * 8 + 10 : (Math.random() - 0.5) * 0.4,
      alpha: Math.random() * 0.35 + 0.1
    });
  }
}

function updateWeatherCanvasMood(conditionText, iconName) {
  const cond = conditionText.toLowerCase();
  if (cond.includes("rain") || cond.includes("shower") || cond.includes("drizzle") || cond.includes("thunderstorm")) {
    weatherCanvasMode = "rain";
  } else {
    weatherCanvasMode = "clear";
  }
  const canvas = document.getElementById("weather-effect-canvas");
  if (canvas) createParticles(canvas.width, canvas.height);
}

/**
 * Helpers: Status and Toast
 */
function setTopbarStatus(text, isPulse) {
  const statusText = document.getElementById("topbar-status-text");
  if (statusText) statusText.textContent = text;
}

function showToast(message, type = "info") {
  const container = document.getElementById("toast-container");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = `toast-item ${type}`;
  toast.textContent = message;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}
