/**
 * WeatherWise AI - Chart Management Engine (Chart.js)
 * Visualizes 24-hour meteorological trends and climate baselines in a sleek dark theme.
 */

let weatherTrendsChartInstance = null;
let climateTrendChartInstance = null;
let currentHourlyData = null;
let currentActiveChartType = 'temp';

/**
 * Initializes or updates the 24-hour meteorological trends chart.
 */
function renderWeatherTrendsChart(hourlyData, chartType = 'temp') {
  currentHourlyData = hourlyData;
  currentActiveChartType = chartType;

  const canvas = document.getElementById('weatherTrendsChart');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  if (weatherTrendsChartInstance) {
    weatherTrendsChartInstance.destroy();
  }

  const times = hourlyData?.times || ["00:00", "03:00", "06:00", "09:00", "12:00", "15:00", "18:00", "21:00"];
  let label = "Temperature (°C)";
  let datasetData = hourlyData?.temperatures || [22, 21, 23, 27, 31, 30, 26, 24];
  let lineColor = "#10B981"; // Emerald
  let fillColor = "rgba(16, 185, 129, 0.15)";
  let unit = "°C";

  if (chartType === 'rain') {
    label = "Precipitation Probability (%)";
    datasetData = hourlyData?.rain_probability || [5, 10, 15, 30, 60, 45, 20, 10];
    lineColor = "#38BDF8"; // Sky blue
    fillColor = "rgba(56, 189, 248, 0.15)";
    unit = "%";
  } else if (chartType === 'humidity') {
    label = "Relative Humidity (%)";
    datasetData = hourlyData?.humidity || [75, 78, 70, 55, 48, 52, 65, 72];
    lineColor = "#34D399"; // Mint
    fillColor = "rgba(52, 211, 153, 0.15)";
    unit = "%";
  } else if (chartType === 'wind') {
    label = "Wind Speed (km/h)";
    datasetData = hourlyData?.wind_speeds || [8, 9, 11, 14, 18, 16, 12, 9];
    lineColor = "#F59E0B"; // Amber
    fillColor = "rgba(245, 158, 11, 0.15)";
    unit = " km/h";
  }

  // Create gradient fill
  const gradient = ctx.createLinearGradient(0, 0, 0, 240);
  gradient.addColorStop(0, fillColor);
  gradient.addColorStop(1, "rgba(6, 9, 15, 0.0)");

  weatherTrendsChartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels: times,
      datasets: [{
        label: label,
        data: datasetData,
        borderColor: lineColor,
        borderWidth: 2.5,
        backgroundColor: gradient,
        fill: true,
        tension: 0.4,
        pointBackgroundColor: lineColor,
        pointBorderColor: "#0B111E",
        pointBorderWidth: 2,
        pointRadius: 3.5,
        pointHoverRadius: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: {
        duration: 800,
        easing: 'easeOutQuart'
      },
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          backgroundColor: 'rgba(11, 17, 30, 0.95)',
          titleColor: '#F8FAFC',
          bodyColor: '#94A3B8',
          borderColor: 'rgba(255, 255, 255, 0.1)',
          borderWidth: 1,
          padding: 10,
          displayColors: false,
          callbacks: {
            label: function(context) {
              return `${context.dataset.label}: ${context.parsed.y}${unit}`;
            }
          }
        }
      },
      scales: {
        x: {
          grid: {
            color: 'rgba(255, 255, 255, 0.04)',
            drawBorder: false
          },
          ticks: {
            color: '#64748B',
            font: { family: 'Plus Jakarta Sans', size: 11 },
            maxRotation: 0,
            autoSkip: true,
            maxTicksLimit: 8
          }
        },
        y: {
          grid: {
            color: 'rgba(255, 255, 255, 0.05)',
            drawBorder: false
          },
          ticks: {
            color: '#64748B',
            font: { family: 'Plus Jakarta Sans', size: 11 },
            callback: function(value) {
              return value + unit;
            }
          }
        }
      }
    }
  });
}

/**
 * Initializes Climate Baseline vs Observed Temperature Chart
 */
function renderClimateTrendChart(climateData) {
  const canvas = document.getElementById('climateTrendChart');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  if (climateTrendChartInstance) {
    climateTrendChartInstance.destroy();
  }

  const months = climateData?.monthly_temperature_averages?.months || ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const baseline = climateData?.monthly_temperature_averages?.historical_baseline_c || [14.2, 17.5, 23.1, 29.4, 33.2, 33.8, 31.0, 29.8, 28.5, 25.4, 20.1, 15.3];
  const currentYear = climateData?.monthly_temperature_averages?.current_year_observed_c || [15.1, 18.9, 24.5, 30.8, 34.1, 34.6, 31.8, 30.2, 29.1, 26.2, 21.0, 16.0];

  climateTrendChartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels: months,
      datasets: [
        {
          label: 'Observed 2025-2026 (°C)',
          data: currentYear,
          borderColor: '#EF4444', // Warm anomaly red
          backgroundColor: 'rgba(239, 68, 68, 0.08)',
          borderWidth: 2.5,
          tension: 0.3,
          fill: true
        },
        {
          label: '10-Year Historical Baseline (°C)',
          data: baseline,
          borderColor: '#10B981', // Nature green baseline
          borderDash: [5, 5],
          borderWidth: 2,
          tension: 0.3,
          fill: false
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'top',
          labels: {
            color: '#94A3B8',
            font: { family: 'Plus Jakarta Sans', size: 11 },
            boxWidth: 12
          }
        }
      },
      scales: {
        x: {
          grid: { color: 'rgba(255, 255, 255, 0.04)' },
          ticks: { color: '#64748B' }
        },
        y: {
          grid: { color: 'rgba(255, 255, 255, 0.05)' },
          ticks: {
            color: '#64748B',
            callback: function(v) { return v + '°C'; }
          }
        }
      }
    }
  });
}
