"""
WeatherWise AI - Flask Backend Application
AI-Powered Weather Intelligence for Every Citizen
Built for hackathons and local VS Code execution.
"""

import os
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv

# Load local environment variables from .env
load_dotenv()

from services.weather_service import fetch_weather_and_forecast, geocode_city
from services.safety_score import calculate_safety_score
from services.alert_service import evaluate_weather_alerts
from services.gemini_service import get_weather_ai_response

app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False

# Cache for latest weather context to streamline chat queries
_LATEST_WEATHER_CACHE = {}


@app.route("/")
def index():
    """Renders the main WeatherWise AI dashboard page."""
    return render_template("index.html")


@app.route("/api/weather", methods=["GET"])
def api_weather():
    """
    Endpoint: /api/weather
    Query Params:
      - city: e.g. "New Delhi", "London"
      - lat, lon: coordinates (optional)
    """
    city = request.args.get("city")
    lat = request.args.get("lat")
    lon = request.args.get("lon")

    data = fetch_weather_and_forecast(city=city, lat=lat, lon=lon)
    if not data or not data.get("success"):
        return jsonify({"success": False, "error": "Unable to fetch weather data for the specified location"}), 400

    # Store into cache
    _LATEST_WEATHER_CACHE["current"] = data["current"]
    _LATEST_WEATHER_CACHE["forecast"] = data["forecast"]
    _LATEST_WEATHER_CACHE["hourly"] = data["hourly"]

    # Calculate safety score and alerts
    safety = calculate_safety_score(data["current"], data["forecast"])
    profile = request.args.get("profile", "General Citizen")
    alerts = evaluate_weather_alerts(data["current"], data["forecast"], profile=profile)

    _LATEST_WEATHER_CACHE["safety"] = safety
    _LATEST_WEATHER_CACHE["alerts"] = alerts

    return jsonify({
        "success": True,
        "current": data["current"],
        "safety": safety,
        "alerts": alerts
    })


@app.route("/api/forecast", methods=["GET"])
def api_forecast():
    """
    Endpoint: /api/forecast
    Returns 7-day forecast and 24-hour trends for charts.
    """
    city = request.args.get("city")
    lat = request.args.get("lat")
    lon = request.args.get("lon")

    data = fetch_weather_and_forecast(city=city, lat=lat, lon=lon)
    if not data or not data.get("success"):
        return jsonify({"success": False, "error": "Forecast unavailable"}), 400

    return jsonify({
        "success": True,
        "location": data["current"]["location"],
        "forecast": data["forecast"],
        "hourly": data["hourly"]
    })


@app.route("/api/alerts", methods=["GET", "POST"])
def api_alerts():
    """
    Endpoint: /api/alerts
    Generates rule-based meteorological alerts based on profile.
    """
    city = request.args.get("city")
    profile = request.args.get("profile", "General Citizen")

    if request.is_json and request.json:
        profile = request.json.get("profile", profile)
        current = request.json.get("current")
        forecast = request.json.get("forecast")
    else:
        current = _LATEST_WEATHER_CACHE.get("current")
        forecast = _LATEST_WEATHER_CACHE.get("forecast")

    if not current:
        data = fetch_weather_and_forecast(city=city)
        current = data["current"]
        forecast = data["forecast"]

    alerts = evaluate_weather_alerts(current, forecast, profile=profile)
    return jsonify({
        "success": True,
        "profile": profile,
        "alerts_count": len(alerts),
        "alerts": alerts
    })


@app.route("/api/safety-score", methods=["GET", "POST"])
def api_safety_score():
    """
    Endpoint: /api/safety-score
    Calculates Weather Safety Score (0-100) with factor explanations.
    """
    current = None
    forecast = None

    if request.is_json and request.json:
        current = request.json.get("current")
        forecast = request.json.get("forecast")

    if not current:
        current = _LATEST_WEATHER_CACHE.get("current")
        forecast = _LATEST_WEATHER_CACHE.get("forecast")

    if not current:
        city = request.args.get("city", "New Delhi")
        data = fetch_weather_and_forecast(city=city)
        current = data["current"]
        forecast = data["forecast"]

    score_data = calculate_safety_score(current, forecast)
    return jsonify({
        "success": True,
        "safety_score": score_data
    })


@app.route("/api/chat", methods=["POST"])
def api_chat():
    """
    Endpoint: /api/chat
    User enters question -> backend merges live weather context -> sends to Gemini AI -> returns actionable advice.
    """
    body = request.get_json(silent=True) or {}
    query = body.get("query", "").strip()
    profile = body.get("profile", "General Citizen")
    language = body.get("language", "en")
    weather_ctx = body.get("weather_context") or _LATEST_WEATHER_CACHE

    if not query:
        return jsonify({"success": False, "error": "Query cannot be empty"}), 400

    # If cache is empty, fetch default city data
    if not weather_ctx or not weather_ctx.get("current"):
        default_data = fetch_weather_and_forecast("New Delhi")
        safety = calculate_safety_score(default_data["current"], default_data["forecast"])
        alerts = evaluate_weather_alerts(default_data["current"], default_data["forecast"], profile=profile)
        weather_ctx = {
            "current": default_data["current"],
            "forecast": default_data["forecast"],
            "safety": safety,
            "alerts": alerts
        }

    ai_answer = get_weather_ai_response(
        user_query=query,
        weather_context=weather_ctx,
        profile=profile,
        language=language
    )

    return jsonify({
        "success": True,
        "query": query,
        "profile": profile,
        "language": language,
        "response": ai_answer
    })


@app.route("/api/climate", methods=["GET"])
def api_climate():
    """
    Endpoint: /api/climate
    Returns sample climate comparison datasets and seasonal insights.
    """
    return jsonify({
        "success": True,
        "monthly_temperature_averages": {
            "months": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
            "historical_baseline_c": [14.2, 17.5, 23.1, 29.4, 33.2, 33.8, 31.0, 29.8, 28.5, 25.4, 20.1, 15.3],
            "current_year_observed_c": [15.1, 18.9, 24.5, 30.8, 34.1, 34.6, 31.8, 30.2, 29.1, 26.2, 21.0, 16.0]
        },
        "rainfall_anomaly": {
            "trend": "+12% monsoon precipitation surge",
            "risk_period": "July - September",
            "drought_resilience_rating": "Moderate"
        },
        "climate_ai_summary": (
            "Regional meteorological observation models show a +1.1°C upward baseline temperature deviation "
            "over the 10-year mean, accompanied by compressed, high-intensity monsoon convective rain bursts. "
            "Sustainable rainwater harvesting and thermal resilient crop variants are recommended."
        ),
        "disclaimer": "Sample baseline climate dataset for educational and hackathon presentation purposes."
    })


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_DEBUG", "True").lower() in ["true", "1"]
    print(f"WeatherWise AI Flask Server starting on http://127.0.0.1:{port}")
    app.run(host="0.0.0.0", port=port, debug=debug)
