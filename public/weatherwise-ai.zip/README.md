# 🌦️ WeatherWise AI — AI-Powered Weather Intelligence for Every Citizen

> **Tagline**: AI-Powered Weather Intelligence for Every Citizen  
> **Built for**: Hackathons, Citizens, Farmers, Travelers & Emergency Services  
> **Tech Stack**: Python Flask, Google Gemini API, HTML5, CSS3, JavaScript, Chart.js, Open-Meteo

WeatherWise AI is an intelligent full-stack conversational weather intelligence platform. It bridges the gap between raw meteorological telemetry and actionable human decision-making, offering live global weather telemetry, 7-day predictive forecasting, transparent Weather Safety Scores, multi-tier severe hazard alerts, and context-aware conversational AI with multilingual Hindi and English fluency.

---

## 📁 Complete Project Folder Structure

```
weatherwise-ai/
│
├── app.py                      # Core Flask web server & API endpoints
├── requirements.txt            # Python dependencies (Flask, requests, dotenv, google-genai)
├── .env.example                # Template for environment keys
├── README.md                   # Comprehensive run and setup guide
│
├── services/
│   ├── weather_service.py      # Real-time weather, geocoding & Open-Meteo integration
│   ├── gemini_service.py       # Google Gemini AI conversational reasoning & fallback
│   ├── alert_service.py        # Configurable rule-based atmospheric risk alerts
│   └── safety_score.py         # Objective 0-100 Weather Safety Score calculation
│
├── templates/
│   └── index.html              # Modern dark futuristic UI dashboard template
│
└── static/
    ├── css/
    │   └── style.css           # Premium dark aesthetic, glassmorphism & emerald accents
    └── js/
        ├── app.js              # Client state, geolocation, voice input & UI events
        └── charts.js           # 24-hour hourly trend line charts via Chart.js
```

---

## 🚀 Beginner-Friendly Step-by-Step Setup Guide (VS Code)

### Step 1: Install Python (if not already installed)
1. Download Python 3.10+ from the official website: [python.org/downloads](https://www.python.org/downloads/)
2. **Important on Windows**: During installation, ensure you check the box **"Add Python to PATH"**.
3. Verify installation in your terminal:
   ```bash
   python --version
   # or on macOS/Linux:
   python3 --version
   ```

---

### Step 2: Open the Project in VS Code
1. Open **Visual Studio Code**.
2. Click **File > Open Folder...** and select the `weatherwise-ai` folder.
3. Open the integrated terminal in VS Code:
   - Press `` Ctrl + ` `` (Windows/Linux) or `` Cmd + ` `` (macOS).

---

### Step 3: Create a Virtual Environment
A virtual environment isolates project dependencies so they don't interfere with other projects:

**On Windows (PowerShell or Command Prompt):**
```bash
python -m venv venv
venv\Scripts\activate
```

**On macOS / Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```
*(You will notice `(venv)` appear at the beginning of your terminal prompt line)*

---

### Step 4: Install Dependencies
Install all required libraries specified in `requirements.txt`:
```bash
pip install -r requirements.txt
```

---

### Step 5: Create Your `.env` Configuration File
Duplicate the template `.env.example` to create `.env`:

**On Windows:**
```bash
copy .env.example .env
```

**On macOS / Linux:**
```bash
cp .env.example .env
```

---

### Step 6: Configure API Keys in `.env`
Open the newly created `.env` file in VS Code:

```env
# 1. Google Gemini API Key (Get free key from https://aistudio.google.com/)
GEMINI_API_KEY=your_gemini_api_key_here

# 2. Weather API (Optional - WeatherWise AI uses Open-Meteo with 0 key required!)
OPENWEATHER_API_KEY=

# 3. Server Configuration
PORT=5000
FLASK_DEBUG=True
```

> **Note on Weather Data**: Out of the box, WeatherWise AI queries Open-Meteo's open global weather and geocoding endpoints. No credit card or paid weather API key is required to get live data for any city on Earth!

---

### Step 7: Run the Flask Server
In your activated virtual environment terminal, execute:
```bash
python app.py
```

You should see output similar to:
```
WeatherWise AI Flask Server starting on http://127.0.0.1:5000
 * Serving Flask app 'app'
 * Debug mode: on
 * Running on all addresses (0.0.0.0)
 * Running on http://127.0.0.1:5000
```

---

### Step 8: Open the Website in Your Browser
Open Google Chrome, Brave, Edge, or Safari and navigate to:
```
http://127.0.0.1:5000
```
or
```
http://localhost:5000
```

---

## 🌟 Key Application Features

1. **Live Weather Dashboard**:
   - Real-time temperature, "feels-like", humidity, wind speed, pressure, UV index, and sunrise/sunset cycles.
   - Dynamic weather conditions with animated icons.

2. **Weather Safety Score (0-100)**:
   - Animated SVG circular gauge.
   - Categorized into *Safe (80-100)*, *Moderate Risk (50-79)*, and *High Risk (0-49)*.
   - Granular breakdown of temperature, wind, and precipitation deductions.

3. **Context-Aware Gemini AI Chatbot**:
   - Ask complex weather questions in **English**, **हिन्दी (Devanagari)**, or **Hinglish** (e.g., *"Kal baarish hogi kya?"*).
   - Voice input integration via the browser Web Speech API.
   - Responses dynamically tailor advice based on active profile.

4. **Multi-Persona Profiles**:
   - 👤 **General Citizen**: Everyday commute, walking, umbrella readiness.
   - 🌾 **Farmer**: Soil moisture, spray drift windows, crop shelter.
   - ✈️ **Traveler**: Highway visibility, hydroplaning risk, transit buffer.
   - 🛡️ **Emergency Services**: Civil drainage overflow, electrical hazard alerts.

5. **24-Hour Trend Charts**:
   - Smooth Chart.js visualization for Hourly Temperature, Rain Probability, Relative Humidity, and Wind Velocities.

6. **Automated Smart Alerts**:
   - Severe weather detection for Heavy Rain, Heatwaves, Gale Winds, Thunderstorms & Lightning.
   - Visual pulsing indicators on Warning and Critical hazards.

7. **Climate Insights Section**:
   - Compares 10-year historical climate baselines against current observed temperatures with AI climate risk summaries.

8. **Atmospheric Rotated YouTube Background Video**:
   - Official ambient YouTube video integration (`1Y30sLKH1fA`) located strictly behind main dashboard content (leaving the sidebar on solid dark navy).
   - Rotated exactly -90° anticlockwise (`transform: translate(-50%, -50%) rotate(-90deg)`), blurred (`14px`), reduced brightness/contrast, subtle opacity (`0.20`), muted, looped, and layered beneath dark navy/emerald gradient overlays.
   - Powered by the official YouTube IFrame Player API for seamless playback, mute enforcement, and infinite replay loops.

---

## 🛠️ Troubleshooting Common Errors

| Issue | Solution |
|---|---|
| `'python' is not recognized as an internal or external command` | Reinstall Python and ensure you check **"Add Python to PATH"** on Windows. |
| `ModuleNotFoundError: No module named 'flask'` | Virtual environment is not activated, or `pip install -r requirements.txt` was not run inside it. Run `source venv/bin/activate` or `venv\Scripts\activate` first. |
| `Port 5000 is already in use` | Change `PORT=5001` in `.env` or run `python app.py` with another port. |
| `Microphone button doesn't respond` | Ensure you granted microphone permission in your browser and are running on `http://localhost` or `https://`. |
| `Gemini AI answers in offline demo mode` | Add your valid Gemini API key to `.env` as `GEMINI_API_KEY=AIzaSy...`. The app works in offline demo mode even without an API key! |
