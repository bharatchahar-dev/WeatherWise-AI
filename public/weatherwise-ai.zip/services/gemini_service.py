"""
WeatherWise AI - Gemini AI Assistant Service
Orchestrates context-aware conversational weather intelligence using Google Gemini API.
Incorporates:
- Live weather context (temperature, humidity, wind, UV, conditions)
- 7-day forecast data
- Weather Safety Score & risk deductions
- Active meteorological alerts
- User profile (Citizen, Farmer, Traveler, Emergency Services)
- Multilingual responses (fluent Hindi, Hinglish, English)
- Clear distinction between verified live sensor observations and general advice
"""

import os
import json
import requests

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")


def get_weather_ai_response(user_query: str, weather_context: dict, profile: str = "General Citizen", language: str = "en") -> str:
    """
    Sends user question and full meteorological context to Google Gemini.
    Provides a comprehensive, actionable, and conversational response.
    """
    api_key = os.getenv("GEMINI_API_KEY", GEMINI_API_KEY)

    # Format context cleanly
    current = weather_context.get("current", {})
    safety = weather_context.get("safety", {})
    alerts = weather_context.get("alerts", [])
    forecast = weather_context.get("forecast", [])

    alerts_summary = ", ".join([f"{a.get('severity')}: {a.get('title')}" for a in alerts]) if alerts else "None"
    forecast_summary = "; ".join([f"{f.get('day')} ({f.get('condition')}, {f.get('min_temp')}°C - {f.get('max_temp')}°C, Rain: {f.get('rain_probability')}%)" for f in forecast[:4]])

    system_instruction = f"""You are 'WeatherWise AI', an expert meteorological intelligence assistant designed for hackathons and citizens worldwide.
You provide clear, accurate, conversational, and actionable weather guidance.

STRICT OPERATIONAL RULES:
1. Always base all statements about current or upcoming weather strictly on the provided Meteorological Context. Do not hallucinate numbers or invent unmeasured live data.
2. Clearly distinguish between verified live observations and general preparedness advice.
3. Tailor your recommendations specifically to the user's selected profile: '{profile}'.
   - Farmer: Focus on soil moisture, irrigation timing, pesticide wash-off risk, crop staking, livestock comfort.
   - Traveler: Focus on highway visibility, hydroplaning risk, transit delays, packing essentials.
   - Emergency Services: Focus on drainage surge, infrastructure vulnerability, power line hazards, priority staging.
   - General Citizen: Focus on daily commutes, outdoor activity suitability, health/hydration, umbrella necessity.
4. Multilingual Awareness:
   - If the user asks in Hindi (Devanagari) or Hinglish (e.g., 'Kal baarish hogi kya?'), respond naturally in Hindi (or clean Hinglish / Devanagari) while keeping key numbers and terms clear.
   - If the user specifies or asks in English, respond in articulate, modern English.
5. Keep responses concise, structured, friendly, and directly actionable with bullet points where helpful. Never be excessively verbose.
"""

    context_prompt = f"""METEOROLOGICAL CONTEXT FOR LOCATION: {current.get('location', 'Current Location')}:
- Current Condition: {current.get('condition', 'Clear')} (Icon: {current.get('icon')})
- Temperature: {current.get('temperature', 25)}°C (Feels like: {current.get('feels_like', 25)}°C)
- Humidity: {current.get('humidity', 50)}% | Wind Speed: {current.get('wind_speed', 10)} km/h
- Pressure: {current.get('pressure', 1013)} hPa | UV Index: {current.get('uv_index', 5)}
- Sunrise: {current.get('sunrise', '06:00')} | Sunset: {current.get('sunset', '18:30')}
- Active Alerts: {alerts_summary}
- Weather Safety Score: {safety.get('score', 95)}/100 ({safety.get('level', 'Safe')})
- Safety Advisory: {safety.get('advisory', 'Normal conditions')}
- 4-Day Forecast Glance: {forecast_summary}

USER PROFILE: {profile}
USER QUESTION: "{user_query}"

Provide an immediate, well-structured, actionable response to the user's question incorporating the weather data above."""

    # 1. If GEMINI_API_KEY is present, call Google Gemini via REST (universal, zero dependency issue)
    if api_key and api_key != "your_gemini_api_key_here" and api_key != "MY_GEMINI_API_KEY":
        try:
            # First try official Gemini 2.5 Flash / 1.5 Flash endpoint
            url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={api_key}"
            payload = {
                "contents": [
                    {
                        "role": "user",
                        "parts": [{"text": f"{system_instruction}\n\n{context_prompt}"}]
                    }
                ],
                "generationConfig": {
                    "temperature": 0.3,
                    "maxOutputTokens": 800
                }
            }
            resp = requests.post(url, json=payload, headers={"Content-Type": "application/json"}, timeout=12)
            if resp.ok:
                result = resp.json()
                text = result.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "")
                if text:
                    return text.strip()
            else:
                # Try fallback model gemini-1.5-flash
                fallback_url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={api_key}"
                resp2 = requests.post(fallback_url, json=payload, headers={"Content-Type": "application/json"}, timeout=10)
                if resp2.ok:
                    result2 = resp2.json()
                    text2 = result2.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "")
                    if text2:
                        return text2.strip()
        except Exception as e:
            print(f"Gemini API invocation error: {e}")

    # 2. High-Quality Fallback Engine (Hackathon Demo & Offline Safe)
    return generate_intelligent_rule_response(user_query, current, safety, alerts, forecast, profile)


def generate_intelligent_rule_response(query: str, current: dict, safety: dict, alerts: list, forecast: list, profile: str) -> str:
    """
    Intelligent natural language weather synthesizer for demo mode or when API key is pending.
    Understands Hindi / Hinglish keywords and profile context!
    """
    q = query.lower()
    temp = current.get("temperature", 25)
    condition = current.get("condition", "Clear")
    score = safety.get("score", 92)
    location = current.get("location", "your area")
    wind = current.get("wind_speed", 12)
    hum = current.get("humidity", 55)

    is_hindi = any(w in q for w in ["kya", "kal", "baarish", "aaj", "hogi", "mausam", "kaisa", "tapman", "chhatri", "surakshit"])

    # Umbrella / Rain questions
    if any(w in q for w in ["umbrella", "rain", "baarish", "barsat", "chhatri", "wet", "shower"]):
        rain_prob = forecast[0].get("rain_probability", 20) if forecast else 20
        tomorrow_rain = forecast[1].get("rain_probability", 25) if len(forecast) > 1 else 25
        
        if is_hindi:
            if rain_prob > 50 or tomorrow_rain > 50:
                return (f"🌧️ **हाँ, छाता साथ रखना ज़रूरी है!**\n\n"
                        f"• **{location}** में बारिश की संभावना **{max(rain_prob, tomorrow_rain)}%** है।\n"
                        f"• वर्तमान स्थिति: **{condition}** (तापमान {temp}°C, नमी {hum}%)।\n"
                        f"• **{profile} सुझाव:** जलभराव से बचें और जल-रोधी (waterproof) बैग या रेनकोट का प्रयोग करें।")
            else:
                return (f"☀️ **फिलहाल छाते की खास ज़रूरत नहीं है।**\n\n"
                        f"• **{location}** में आज बारिश की संभावना केवल **{rain_prob}%** है।\n"
                        f"• मौसम अधिकांशतः **{condition}** रहेगा (तापमान {temp}°C)।\n"
                        f"• फिर भी दोपहर की तेज़ धूप (UV {current.get('uv_index', 5)}) से बचने के लिए टोपी या धूप का चश्मा रख सकते हैं।")
        else:
            if rain_prob > 50 or tomorrow_rain > 50:
                return (f"🌧️ **Yes, carrying an umbrella is strongly recommended!**\n\n"
                        f"• **Rain Probability:** {max(rain_prob, tomorrow_rain)}% in **{location}**.\n"
                        f"• **Current Observation:** {condition} at {temp}°C with {hum}% relative humidity.\n"
                        f"• **Recommendation for {profile}:** Expect intermittent precipitation. Protect sensitive electronics and wear non-slip footwear.")
            else:
                return (f"🌤️ **No umbrella required right now.**\n\n"
                        f"• **Precipitation Risk:** Only {rain_prob}% chance of rain in **{location}**.\n"
                        f"• **Current Conditions:** {condition} at {temp}°C, wind speed {wind} km/h.\n"
                        f"• **Safety Score:** {score}/100 ({safety.get('level', 'Safe')}). Great day for your routine activities!")

    # Travel / Outdoor questions
    if any(w in q for w in ["travel", "safe", "safari", "trip", "drive", "road", "yatra", "surakshit", "outdoor", "walk"]):
        if is_hindi:
            return (f"🚗 **यात्रा सुरक्षा मूल्यांकन ({location}):**\n\n"
                    f"• **वेदर सेफ्टी स्कोर:** **{score}/100** ({safety.get('level_hindi', 'सुरक्षित')})\n"
                    f"• **वर्तमान स्थिति:** {condition}, तापमान {temp}°C, हवा {wind} किमी/घंटा।\n"
                    f"• **प्रोफाइल ({profile}) सलाह:** "
                    + ("सड़कों पर दृश्यता अच्छी है, सामान्य सावधानी के साथ यात्रा की जा सकती है।" if score >= 70 else "मौसम में जोखिम है। गति नियंत्रित रखें और मौसम अपडेट पर नज़र रखें।"))
        else:
            status_text = "Favorable for travel" if score >= 80 else ("Proceed with moderate caution" if score >= 50 else "High hazard - delay non-essential travel")
            return (f"🛡️ **Travel & Outdoor Safety Assessment for {location}:**\n\n"
                    f"• **Weather Safety Score:** **{score}/100** ({safety.get('level', 'Safe')}) - *{status_text}*\n"
                    f"• **Current Metric Check:** {condition} at {temp}°C, Wind {wind} km/h, Visibility ~10 km.\n"
                    f"• **Tailored for {profile}:** {safety.get('advisory', 'Normal conditions prevailing.')}\n"
                    f"• **Pro-Tip:** Check tyre pressures and keep mobile devices adequately charged.")

    # Farmer / Agriculture questions
    if any(w in q for w in ["farm", "crop", "kisan", "kheti", "irrigation", "spray", "soil"]):
        if is_hindi:
            return (f"🌾 **किसान सलाहकार ({profile} मोड):**\n\n"
                    f"• **तापमान एवं नमी:** {temp}°C | हवा में नमी: {hum}% | हवा की गति: {wind} किमी/घंटा।\n"
                    f"• **सिंचाई सुझाव:** {'मौसम शुष्क रहने का अनुमान है, आवश्यकतानुसार हल्की सिंचाई कर सकते हैं।' if current.get('precipitation_mm', 0) < 2 else 'बारिश की संभावना है, सिंचाई रोक दें।'}\n"
                    f"• **कीटनाशक छिड़काव:** {'हवा की गति सामान्य है, छिड़काव किया जा सकता है।' if wind < 20 else 'तेज़ हवा के कारण कीटनाशक का बहाव होगा, छिड़काव टालें।'}")
        else:
            return (f"🌾 **Agricultural Advisory ({profile} Mode):**\n\n"
                    f"• **Soil & Air Metrics:** {temp}°C ambient temperature, {hum}% relative humidity, wind speed {wind} km/h.\n"
                    f"• **Irrigation Action:** {'Light irrigation feasible based on soil moisture levels.' if current.get('precipitation_mm', 0) < 2 else 'Hold off irrigation as natural precipitation is incoming.'}\n"
                    f"• **Field Operations:** {'Winds are within normal drift tolerances for crop spraying.' if wind < 20 else 'High wind velocity may cause chemical spray drift; reschedule application.'}")

    # General / Default response
    if is_hindi:
        return (f"🌤️ **{location} के लिए WeatherWise AI रिपोर्ट:**\n\n"
                f"• वर्तमान में मौसम **{condition}** है, तापमान **{temp}°C** (महसूस: {current.get('feels_like', temp)}°C)।\n"
                f"• हवा की गति **{wind} किमी/घंटा** और नमी **{hum}%** है।\n"
                f"• **सेफ्टी स्कोर:** **{score}/100** ({safety.get('level_hindi', 'सुरक्षित')})।\n"
                f"• **{profile} के लिए सलाह:** {safety.get('advisory_hindi', 'दिन की योजना सामान्य रूप से बना सकते हैं।')}")
    else:
        return (f"🌤️ **WeatherWise AI Intelligence Report for {location}:**\n\n"
                f"• **Current Atmosphere:** **{condition}** at **{temp}°C** (Feels like **{current.get('feels_like', temp)}°C**).\n"
                f"• **Atmospheric Indices:** Wind {wind} km/h | Humidity {hum}% | UV Index {current.get('uv_index', 5)}.\n"
                f"• **Weather Safety Score:** **{score}/100** ({safety.get('level', 'Safe')}).\n"
                f"• **Advisory for {profile}:** {safety.get('advisory', 'Enjoy favorable outdoor conditions.')}\n"
                f"• Feel free to ask specific questions about rainfall timings, travel safety, or farming guidance!")
