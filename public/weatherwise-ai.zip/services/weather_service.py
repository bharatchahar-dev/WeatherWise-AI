"""
WeatherWise AI - Weather Data Service
Fetches live and forecast weather data using Open-Meteo API (free global open data, no key required)
with optional fallback/support for OpenWeatherMap if OPENWEATHER_API_KEY is configured.
Also provides realistic demo fallback data if network is unavailable.
"""

import os
import requests
from datetime import datetime

WMO_WEATHER_CODES = {
    0: ("Clear Sky", "sun"),
    1: ("Mainly Clear", "sun"),
    2: ("Partly Cloudy", "cloud-sun"),
    3: ("Overcast", "cloud"),
    45: ("Foggy", "cloud-fog"),
    48: ("Depositing Rime Fog", "cloud-fog"),
    51: ("Light Drizzle", "cloud-drizzle"),
    53: ("Moderate Drizzle", "cloud-drizzle"),
    55: ("Dense Drizzle", "cloud-rain"),
    61: ("Slight Rain", "cloud-rain"),
    63: ("Moderate Rain", "cloud-rain"),
    65: ("Heavy Rain", "cloud-rain-wind"),
    71: ("Slight Snow", "cloud-snow"),
    73: ("Moderate Snow", "cloud-snow"),
    75: ("Heavy Snow", "snowflake"),
    80: ("Rain Showers", "cloud-rain"),
    81: ("Moderate Rain Showers", "cloud-rain"),
    82: ("Violent Rain Showers", "cloud-lightning"),
    95: ("Thunderstorm", "cloud-lightning"),
    96: ("Thunderstorm with Slight Hail", "cloud-lightning"),
    99: ("Thunderstorm with Heavy Hail", "cloud-lightning"),
}

DEFAULT_CITIES = {
    "new delhi": (28.6139, 77.2090, "New Delhi, India"),
    "mumbai": (19.0760, 72.8777, "Mumbai, India"),
    "london": (51.5074, -0.1278, "London, United Kingdom"),
    "new york": (40.7128, -74.0060, "New York, United States"),
    "tokyo": (35.6762, 139.6503, "Tokyo, Japan"),
    "paris": (48.8566, 2.3522, "Paris, France"),
    "bengaluru": (12.9716, 77.5946, "Bengaluru, India"),
    "singapore": (1.3521, 103.8198, "Singapore"),
}


def geocode_city(city_name: str):
    """Resolve city name into (lat, lon, display_name) using Open-Meteo Geocoding API."""
    query = city_name.strip().lower()
    if query in DEFAULT_CITIES:
        return DEFAULT_CITIES[query]

    try:
        url = "https://geocoding-api.open-meteo.com/v1/search"
        resp = requests.get(url, params={"name": city_name, "count": 1, "language": "en", "format": "json"}, timeout=5)
        if resp.ok:
            data = resp.json()
            if "results" in data and len(data["results"]) > 0:
                res = data["results"][0]
                lat = res.get("latitude")
                lon = res.get("longitude")
                country = res.get("country", "")
                admin1 = res.get("admin1", "")
                name = res.get("name", city_name)
                display_parts = [p for p in [name, admin1, country] if p]
                display_name = ", ".join(display_parts)
                return (lat, lon, display_name)
    except Exception as e:
        print(f"Geocoding error for {city_name}: {e}")

    # Fallback to New Delhi if not found
    return (28.6139, 77.2090, city_name.title())


def fetch_weather_and_forecast(city=None, lat=None, lon=None):
    """
    Fetches real-time weather and 7-day forecast from Open-Meteo.
    Returns complete structured dictionary.
    """
    location_name = "Detected Location"
    if city:
        lat, lon, location_name = geocode_city(city)
    elif lat is not None and lon is not None:
        try:
            lat = float(lat)
            lon = float(lon)
            location_name = f"Coordinates ({lat:.2f}°, {lon:.2f}°)"
        except (ValueError, TypeError):
            lat, lon, location_name = (28.6139, 77.2090, "New Delhi, India")
    else:
        lat, lon, location_name = (28.6139, 77.2090, "New Delhi, India")

    try:
        params = {
            "latitude": lat,
            "longitude": lon,
            "current": "temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,surface_pressure,wind_speed_10m,wind_direction_10m",
            "hourly": "temperature_2m,relative_humidity_2m,precipitation_probability,wind_speed_10m,uv_index",
            "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,uv_index_max,sunrise,sunset,wind_speed_10m_max",
            "timezone": "auto",
            "forecast_days": 7
        }
        url = "https://api.open-meteo.com/v1/forecast"
        resp = requests.get(url, params=params, timeout=7)
        if resp.ok:
            data = resp.json()
            curr = data.get("current", {})
            daily = data.get("daily", {})
            hourly = data.get("hourly", {})

            w_code = curr.get("weather_code", 0)
            condition_text, icon_name = WMO_WEATHER_CODES.get(w_code, ("Clear", "sun"))

            # Sunrise & sunset
            sunrise_list = daily.get("sunrise", [])
            sunset_list = daily.get("sunset", [])
            sunrise_str = sunrise_list[0].split("T")[-1] if sunrise_list else "06:00"
            sunset_str = sunset_list[0].split("T")[-1] if sunset_list else "18:30"

            # UV Index from hourly or daily
            daily_uv = daily.get("uv_index_max", [5.0])
            uv_val = daily_uv[0] if daily_uv else 5.2

            # Forecast list
            forecast_items = []
            days_count = min(7, len(daily.get("time", [])))
            for i in range(days_count):
                date_str = daily["time"][i]
                dt = datetime.strptime(date_str, "%Y-%m-%d")
                day_name = dt.strftime("%A") if i > 0 else "Today"
                code = daily["weather_code"][i]
                cond, icon = WMO_WEATHER_CODES.get(code, ("Clear", "sun"))
                forecast_items.append({
                    "day": day_name,
                    "date": dt.strftime("%b %d"),
                    "min_temp": round(daily["temperature_2m_min"][i], 1),
                    "max_temp": round(daily["temperature_2m_max"][i], 1),
                    "rain_probability": int(daily.get("precipitation_probability_max", [0])[i] or 0),
                    "condition": cond,
                    "icon": icon,
                    "wind_speed": round(daily.get("wind_speed_10m_max", [12.0])[i], 1)
                })

            # Hourly chart data (next 24 hours)
            hourly_times = [t.split("T")[-1][:5] for t in hourly.get("time", [])[:24]]
            hourly_temps = [round(t, 1) for t in hourly.get("temperature_2m", [])[:24]]
            hourly_humidity = hourly.get("relative_humidity_2m", [])[:24]
            hourly_rain_prob = [p or 0 for p in hourly.get("precipitation_probability", [])[:24]]
            hourly_winds = [round(w, 1) for w in hourly.get("wind_speed_10m", [])[:24]]

            current_payload = {
                "location": location_name,
                "latitude": lat,
                "longitude": lon,
                "temperature": round(curr.get("temperature_2m", 24.0), 1),
                "feels_like": round(curr.get("apparent_temperature", 25.0), 1),
                "humidity": curr.get("relative_humidity_2m", 55),
                "wind_speed": round(curr.get("wind_speed_10m", 12.0), 1),
                "wind_direction": curr.get("wind_direction_10m", 180),
                "pressure": round(curr.get("surface_pressure", 1013.2), 1),
                "uv_index": round(uv_val, 1),
                "weather_code": w_code,
                "condition": condition_text,
                "icon": icon_name,
                "sunrise": sunrise_str,
                "sunset": sunset_str,
                "visibility_km": 10.0,
                "last_updated": datetime.now().strftime("%I:%M %p"),
                "is_demo": False,
                "precipitation_mm": curr.get("precipitation", 0.0)
            }

            return {
                "success": True,
                "current": current_payload,
                "forecast": forecast_items,
                "hourly": {
                    "times": hourly_times,
                    "temperatures": hourly_temps,
                    "humidity": hourly_humidity,
                    "rain_probability": hourly_rain_prob,
                    "wind_speeds": hourly_winds
                }
            }
    except Exception as e:
        print(f"Weather API fetch failed, switching to demo mode: {e}")

    # Realistic Demo Mode Fallback
    return get_demo_weather(location_name, lat, lon)


def get_demo_weather(location_name="New Delhi, India", lat=28.61, lon=77.20):
    """Provides a realistic demo weather dataset if the external API cannot be reached."""
    now = datetime.now()
    return {
        "success": True,
        "current": {
            "location": location_name,
            "latitude": lat,
            "longitude": lon,
            "temperature": 27.5,
            "feels_like": 29.2,
            "humidity": 62,
            "wind_speed": 14.8,
            "wind_direction": 210,
            "pressure": 1012.4,
            "uv_index": 6.8,
            "weather_code": 2,
            "condition": "Partly Cloudy",
            "icon": "cloud-sun",
            "sunrise": "06:12",
            "sunset": "18:45",
            "visibility_km": 8.5,
            "last_updated": now.strftime("%I:%M %p"),
            "is_demo": True,
            "precipitation_mm": 0.0
        },
        "forecast": [
            {"day": "Today", "date": now.strftime("%b %d"), "min_temp": 21.0, "max_temp": 31.5, "rain_probability": 15, "condition": "Partly Cloudy", "icon": "cloud-sun", "wind_speed": 14.8},
            {"day": "Tomorrow", "date": "Day 2", "min_temp": 22.0, "max_temp": 32.0, "rain_probability": 35, "condition": "Scattered Clouds", "icon": "cloud", "wind_speed": 16.0},
            {"day": "Wednesday", "date": "Day 3", "min_temp": 20.5, "max_temp": 28.0, "rain_probability": 75, "condition": "Moderate Rain", "icon": "cloud-rain", "wind_speed": 22.4},
            {"day": "Thursday", "date": "Day 4", "min_temp": 19.0, "max_temp": 26.5, "rain_probability": 85, "condition": "Thunderstorm", "icon": "cloud-lightning", "wind_speed": 28.0},
            {"day": "Friday", "date": "Day 5", "min_temp": 19.5, "max_temp": 29.0, "rain_probability": 40, "condition": "Passing Showers", "icon": "cloud-drizzle", "wind_speed": 15.2},
            {"day": "Saturday", "date": "Day 6", "min_temp": 21.5, "max_temp": 32.5, "rain_probability": 10, "condition": "Mainly Clear", "icon": "sun", "wind_speed": 11.5},
            {"day": "Sunday", "date": "Day 7", "min_temp": 22.0, "max_temp": 33.0, "rain_probability": 5, "condition": "Clear Sky", "icon": "sun", "wind_speed": 10.0},
        ],
        "hourly": {
            "times": ["00:00", "02:00", "04:00", "06:00", "08:00", "10:00", "12:00", "14:00", "16:00", "18:00", "20:00", "22:00"],
            "temperatures": [22.1, 21.0, 20.4, 21.8, 25.3, 28.5, 30.8, 31.2, 29.5, 27.2, 25.0, 23.4],
            "humidity": [75, 78, 80, 76, 68, 58, 52, 50, 56, 64, 70, 74],
            "rain_probability": [5, 5, 10, 10, 15, 20, 25, 30, 20, 15, 10, 5],
            "wind_speeds": [9.0, 8.5, 8.0, 10.2, 12.5, 14.8, 16.2, 17.0, 15.5, 12.0, 10.5, 9.8]
        }
    }
