"""
WeatherWise AI - Weather Safety Score Calculation Engine
Calculates an objective, transparent safety index from 0 to 100 based on current and forecast conditions.
Includes clear sub-scores for wind, rain, temperature, and atmospheric severity.
"""

def calculate_safety_score(current_weather, forecast=None):
    """
    Computes safety score (0-100) and provides factors breakdown.
    Levels:
    - 80 - 100: Safe (Normal activities permitted)
    - 50 - 79: Moderate Risk (Caution advised for sensitive groups & outdoor work)
    - 0 - 49: High Risk (Hazardous conditions, seek shelter or avoid travel)
    """
    score = 100
    deductions = []
    
    temp = current_weather.get("temperature", 25.0)
    wind_speed = current_weather.get("wind_speed", 10.0)
    humidity = current_weather.get("humidity", 50)
    weather_code = current_weather.get("weather_code", 0)
    uv_index = current_weather.get("uv_index", 5.0)
    precipitation = current_weather.get("precipitation_mm", 0.0)

    # 1. Extreme Temperature Deductions
    temp_deduction = 0
    if temp >= 42:
        temp_deduction = 25
        deductions.append(f"Extreme Heat ({temp}°C) - Danger of heat stroke")
    elif temp >= 38:
        temp_deduction = 15
        deductions.append(f"High Heat ({temp}°C) - Limit direct sun exposure")
    elif temp <= 0:
        temp_deduction = 25
        deductions.append(f"Freezing Conditions ({temp}°C) - Frostbite & ice risk")
    elif temp <= 5:
        temp_deduction = 10
        deductions.append(f"Cold Stress ({temp}°C) - Warm thermal layers required")
    score -= temp_deduction

    # 2. Wind Conditions Deductions
    wind_deduction = 0
    if wind_speed >= 60:
        wind_deduction = 30
        deductions.append(f"Gale Force Winds ({wind_speed} km/h) - Flying debris risk")
    elif wind_speed >= 40:
        wind_deduction = 18
        deductions.append(f"Strong Gusty Winds ({wind_speed} km/h) - High-profile vehicle hazard")
    elif wind_speed >= 28:
        wind_deduction = 8
        deductions.append(f"Breezy Conditions ({wind_speed} km/h)")
    score -= wind_deduction

    # 3. Precipitation & Rain Deductions
    rain_deduction = 0
    if precipitation >= 25:
        rain_deduction = 30
        deductions.append(f"Torrential Downpour ({precipitation} mm/h) - Waterlogging & flash flood threat")
    elif precipitation >= 10:
        rain_deduction = 18
        deductions.append(f"Heavy Rain ({precipitation} mm/h) - Low road friction")
    elif precipitation > 0.5:
        rain_deduction = 8
        deductions.append(f"Active Rain ({precipitation} mm/h)")
    score -= rain_deduction

    # 4. Severe Weather Code Deductions (Thunderstorms, Hail, Snow)
    severe_deduction = 0
    if weather_code in [95, 96, 99]:
        severe_deduction = 35
        deductions.append("Thunderstorm & Lightning Activity - Immediate indoor shelter required")
    elif weather_code in [65, 82]:
        severe_deduction = 20
        deductions.append("Violent Rain Showers - Severely impaired visibility")
    elif weather_code in [71, 73, 75]:
        severe_deduction = 22
        deductions.append("Active Snowfall - Slick road hazard")
    elif weather_code in [45, 48]:
        severe_deduction = 12
        deductions.append("Dense Fog - Dangerous driving visibility (< 500m)")
    score -= severe_deduction

    # 5. UV Radiation Hazard
    uv_deduction = 0
    if uv_index >= 11:
        uv_deduction = 10
        deductions.append(f"Extreme UV Radiation ({uv_index}) - Burns in < 10 minutes")
    elif uv_index >= 8:
        uv_deduction = 5
        deductions.append(f"Very High UV ({uv_index})")
    score -= uv_deduction

    # Normalize score between 0 and 100
    final_score = max(5, min(100, score))

    if final_score >= 80:
        level = "Safe"
        level_hi = "सुरक्षित (Safe)"
        color = "#10B981" # emerald
        advisory = "Favorable weather conditions. Ideal for regular outdoor activities, travel, and farming."
        advisory_hi = "मौसम अनुकूल है। नियमित बाहरी गतिविधियों, यात्रा और खेती के लिए आदर्श।"
    elif final_score >= 50:
        level = "Moderate Risk"
        level_hi = "मध्यम जोखिम (Moderate Risk)"
        color = "#F59E0B" # amber
        advisory = "Moderate atmospheric hazards detected. Plan accordingly, carry appropriate gear, and monitor updates."
        advisory_hi = "मध्यम मौसमी जोखिम दर्ज किया गया है। आवश्यक सावधानी बरतें और मौसम पर नज़र रखें।"
    else:
        level = "High Risk"
        level_hi = "उच्च जोखिम (High Risk)"
        color = "#EF4444" # red
        advisory = "Significant weather hazard active. Postpone non-essential travel and stay in secured structures."
        advisory_hi = "गंभीर मौसमी संकट। गैर-जरूरी यात्रा से बचें और सुरक्षित स्थानों पर रहें।"

    return {
        "score": final_score,
        "level": level,
        "level_hindi": level_hi,
        "color": color,
        "advisory": advisory,
        "advisory_hindi": advisory_hi,
        "deductions": deductions if deductions else ["No significant weather hazards detected."],
        "subscores": {
            "temperature_safety": max(0, 100 - temp_deduction * 4),
            "wind_safety": max(0, 100 - wind_deduction * 3),
            "rain_safety": max(0, 100 - rain_deduction * 3),
            "atmospheric_safety": max(0, 100 - severe_deduction * 2)
        },
        "disclaimer": "AI-generated risk index for situational awareness only. Not an official government civil protection alert."
    }
