"""
WeatherWise AI - Smart Alert Engine
Evaluates atmospheric conditions against rule-based thresholds to generate
structured risk alerts (INFO, WARNING, CRITICAL) customized by profile:
- General Citizen
- Farmer
- Traveler
- Emergency Services
"""

# Configurable Threshold Constants
THRESHOLDS = {
    "HEATWAVE_CRITICAL_TEMP": 42.0,
    "HEATWAVE_WARNING_TEMP": 38.0,
    "COLD_WAVE_WARNING_TEMP": 4.0,
    "HIGH_WIND_CRITICAL_KMH": 55.0,
    "HIGH_WIND_WARNING_KMH": 38.0,
    "HEAVY_RAIN_CRITICAL_MM": 25.0,
    "HEAVY_RAIN_WARNING_MM": 10.0,
    "UV_DANGEROUS_INDEX": 9.0,
}


def evaluate_weather_alerts(current_weather, forecast=None, profile="General Citizen"):
    """
    Evaluates conditions and returns a list of active alerts.
    Each alert has:
    - id, title, type, severity (INFO | WARNING | CRITICAL)
    - description, recommendation, profile_specific_action, icon, timestamp
    """
    alerts = []
    
    temp = current_weather.get("temperature", 25.0)
    feels_like = current_weather.get("feels_like", 25.0)
    wind_speed = current_weather.get("wind_speed", 10.0)
    rain_mm = current_weather.get("precipitation_mm", 0.0)
    weather_code = current_weather.get("weather_code", 0)
    uv_index = current_weather.get("uv_index", 5.0)
    humidity = current_weather.get("humidity", 50)

    # 1. Thunderstorm & Lightning Detection
    if weather_code in [95, 96, 99]:
        severity = "CRITICAL" if weather_code == 99 else "WARNING"
        profile_actions = {
            "Farmer": "Halt all open field operations immediately. Disconnect metal irrigation pipes and move livestock into grounded covered sheds.",
            "Traveler": "Expect flight delays and highway waterlogging. Pull off under solid highway overpasses or structures away from tall solitary trees.",
            "Emergency Services": "Stage swift-water rescue units and monitor urban drainage chokepoints. Prepare auxiliary power generators.",
            "General Citizen": "Stay indoors away from windows and balconies. Unplug sensitive electronics and avoid running water during active lightning."
        }
        alerts.append({
            "id": "alert-thunderstorm",
            "type": "Thunderstorm & Lightning",
            "severity": severity,
            "title": "Severe Thunderstorm & Lightning Alert",
            "title_hi": "गंभीर तूफान और बिजली गिरने की चेतावनी",
            "description": f"Convective storm system active in your zone with intense electrical discharges and heavy wind gusts.",
            "description_hi": "आपके क्षेत्र में तेज़ हवाओं और बिजली चमकने के साथ तूफान सक्रिय है।",
            "recommendation": "Seek sturdy indoor shelter immediately. Avoid metal objects and open water.",
            "profile_action": profile_actions.get(profile, profile_actions["General Citizen"]),
            "icon": "zap",
            "pulse": True
        })

    # 2. Heavy Rain & Flood Risk
    if rain_mm >= THRESHOLDS["HEAVY_RAIN_CRITICAL_MM"] or weather_code in [65, 82]:
        profile_actions = {
            "Farmer": "Dig diversion runoff trenches along field perimeters. Secure harvest storage from dampness and fungus proliferation.",
            "Traveler": "Avoid low-lying underpasses and mountain ghats prone to landslides. Switch vehicle headlights to low beam.",
            "Emergency Services": "Deploy pumps to subterranean transit hubs. Issue evacuation notices for riverbank settlements.",
            "General Citizen": "Avoid driving through standing water of unknown depth. Keep emergency flashlights and dry food accessible."
        }
        alerts.append({
            "id": "alert-heavy-rain",
            "type": "Possible Flood Risk",
            "severity": "CRITICAL",
            "title": "Torrential Downpour & Flash Flood Threat",
            "title_hi": "भारी बारिश और अचानक बाढ़ का खतरा",
            "description": f"Intense precipitation rate ({rain_mm} mm/h) may exceed municipal storm runoff capacities.",
            "description_hi": f"तेज़ बारिश ({rain_mm} मिमी/घंटा) से निचले इलाकों में जलभराव हो सकता है।",
            "recommendation": "Stay on elevated ground. Do not walk or drive through flowing water.",
            "profile_action": profile_actions.get(profile, profile_actions["General Citizen"]),
            "icon": "alert-triangle",
            "pulse": True
        })
    elif rain_mm >= THRESHOLDS["HEAVY_RAIN_WARNING_MM"] or weather_code in [63, 81]:
        profile_actions = {
            "Farmer": "Postpone pesticide spraying as wash-off is guaranteed. Inspect seedling drainage channels.",
            "Traveler": "Add 30-45 minutes buffer to urban commutes. Road surfaces are slick.",
            "Emergency Services": "Pre-alert municipal road clearing teams.",
            "General Citizen": "Carry waterproof rainwear, avoid puddles near exposed electrical poles."
        }
        alerts.append({
            "id": "alert-moderate-rain",
            "type": "Heavy Rain",
            "severity": "WARNING",
            "title": "Sustained Rain Advisory",
            "title_hi": "लगातार बारिश की सलाह",
            "description": f"Continuous rainfall ({rain_mm} mm/h) reducing visibility and causing localized surface pooling.",
            "description_hi": f"लगातार बारिश ({rain_mm} मिमी/घंटा) से दृश्यता कम हो रही है।",
            "recommendation": "Use waterproof gear and reduce vehicular speeds.",
            "profile_action": profile_actions.get(profile, profile_actions["General Citizen"]),
            "icon": "cloud-rain",
            "pulse": False
        })

    # 3. Heatwave & High Temperature
    if temp >= THRESHOLDS["HEATWAVE_CRITICAL_TEMP"] or feels_like >= 44.0:
        profile_actions = {
            "Farmer": "Schedule field irrigation exclusively during night or early dawn (04:00 - 06:00) to prevent soil baking.",
            "Traveler": "Carry minimum 2 liters of electrolyte water in vehicles. Check tyre pressures to prevent blowouts.",
            "Emergency Services": "Open community cooling hydration shelters. Expect surge in cardiac and heat exhaustion admissions.",
            "General Citizen": "Strictly avoid direct sunlight between 11:30 AM and 04:00 PM. Keep wet towels and oral rehydration handy."
        }
        alerts.append({
            "id": "alert-heatwave-crit",
            "type": "Heatwave",
            "severity": "CRITICAL",
            "title": "Extreme Heatwave Hazard",
            "title_hi": "भीषण लू (Heatwave) चेतावनी",
            "description": f"Dangerous ambient temperature ({temp}°C) with heat index reaching {feels_like}°C.",
            "description_hi": f"अत्यधिक तापमान ({temp}°C) और लू का खतरा।",
            "recommendation": "Risk of rapid dehydration and heat stroke. Remain in climate-controlled spaces.",
            "profile_action": profile_actions.get(profile, profile_actions["General Citizen"]),
            "icon": "flame",
            "pulse": True
        })
    elif temp >= THRESHOLDS["HEATWAVE_WARNING_TEMP"]:
        profile_actions = {
            "Farmer": "Provide shade covers for saplings and ample clean water troughs for farm cattle.",
            "Traveler": "Use sun visors, sunglasses, and check engine coolant levels.",
            "Emergency Services": "Monitor vulnerable elder care centers.",
            "General Citizen": "Drink water frequently, wear light cotton clothing, and apply SPF 50+ sunscreen."
        }
        alerts.append({
            "id": "alert-heatwave-warn",
            "type": "Heatwave",
            "severity": "WARNING",
            "title": "Elevated Heat Advisory",
            "title_hi": "गर्मी की चेतावनी",
            "description": f"High temperatures ({temp}°C) prevailing. Heat exhaustion risk during prolonged exposure.",
            "description_hi": f"तेज़ धूप और तापमान ({temp}°C)।",
            "recommendation": "Hydrate regularly and avoid strenuous outdoor exercise midday.",
            "profile_action": profile_actions.get(profile, profile_actions["General Citizen"]),
            "icon": "sun",
            "pulse": False
        })

    # 4. High Wind Conditions
    if wind_speed >= THRESHOLDS["HIGH_WIND_CRITICAL_KMH"]:
        profile_actions = {
            "Farmer": "Anchor polyhouse tarpaulins and stake vulnerable tall crops (maize, banana plantations).",
            "Traveler": "High risk for two-wheelers and high-sided trucks on bridges and open expressways.",
            "Emergency Services": "Prepare arborists and power line restoration crews for fallen tree clearing.",
            "General Citizen": "Secure loose balcony furniture, flowerpots, and tin roofing sheets."
        }
        alerts.append({
            "id": "alert-gale-wind",
            "type": "Strong Wind",
            "severity": "CRITICAL",
            "title": "Severe Gale & Windstorm Warning",
            "title_hi": "तेज़ आंधी और तूफानी हवाओं की चेतावनी",
            "description": f"Damaging winds exceeding {wind_speed} km/h recorded. Risk of falling tree limbs and flying debris.",
            "description_hi": f"{wind_speed} किमी/घंटा की गति से तेज़ हवाएं।",
            "recommendation": "Keep clear of unstable billboards, power poles, and old trees.",
            "profile_action": profile_actions.get(profile, profile_actions["General Citizen"]),
            "icon": "wind",
            "pulse": True
        })
    elif wind_speed >= THRESHOLDS["HIGH_WIND_WARNING_KMH"]:
        profile_actions = {
            "Farmer": "Delay drone and pesticide mist spraying due to severe drift.",
            "Traveler": "Maintain firm grip on steering wheel during crosswinds.",
            "Emergency Services": "Monitor port and small craft nautical advisories.",
            "General Citizen": "Close windows securely against dust infiltration."
        }
        alerts.append({
            "id": "alert-strong-wind",
            "type": "Strong Wind",
            "severity": "WARNING",
            "title": "Brisk Wind Advisory",
            "title_hi": "तेज़ हवा की सलाह",
            "description": f"Sustained wind velocities up to {wind_speed} km/h may blow lightweight items.",
            "description_hi": f"हवा की गति {wind_speed} किमी/घंटा तक पहुंच रही है।",
            "recommendation": "Secure lightweight items on patios and balconies.",
            "profile_action": profile_actions.get(profile, profile_actions["General Citizen"]),
            "icon": "wind",
            "pulse": False
        })

    # 5. Default Normal Advisory if no high alerts
    if not alerts:
        alerts.append({
            "id": "alert-normal-status",
            "type": "General Advisory",
            "severity": "INFO",
            "title": "Atmospheric Conditions Stable",
            "title_hi": "मौसम की स्थिति सामान्य",
            "description": f"No critical meteorological hazards detected in the immediate area. Current temperature is {temp}°C with calm winds ({wind_speed} km/h).",
            "description_hi": f"कोई गंभीर मौसमी खतरा नहीं है। तापमान {temp}°C और हवा शांत ({wind_speed} किमी/घंटा) है।",
            "recommendation": "All routine activities can proceed without weather-related disruptions.",
            "profile_action": f"Recommended for {profile}: Great day to proceed with normal operational schedules and outdoor plans.",
            "icon": "check-circle",
            "pulse": False
        })

    return alerts
